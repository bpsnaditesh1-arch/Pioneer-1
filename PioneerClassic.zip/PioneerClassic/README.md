# Pioneer Classic – Android app

Build the APK (needs Android Studio, free, with internet for the first sync):
1. Unzip this folder.
2. Android Studio → File → Open → choose the PioneerClassic folder. Wait for "Gradle sync" to finish.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Click "locate" in the popup. app-debug.apk is in app/build/outputs/apk/debug/.
5. Copy it to your phone and open it (allow "install unknown apps" if asked).

The player page lives in app/src/main/assets/pioneer.html.
