package com.pioneer.classic

import android.app.Activity
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.webkit.JavascriptInterface

/** Functions the player page can call as window.Android.* */
class Bridge(private val a: Activity) {

    /** Name of the connected Bluetooth audio device, or "" if none. */
    @JavascriptInterface
    fun btDevice(): String = try {
        val am = a.getSystemService(AudioManager::class.java)
        val d = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
        d?.productName?.toString()?.ifBlank { "BLUETOOTH" } ?: ""
    } catch (e: Exception) { "" }

    @JavascriptInterface
    fun openBluetooth() {
        a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
    }

    /** "idle", "ringing" or "offhook". */
    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun callState(): String = try {
        when (a.getSystemService(TelephonyManager::class.java).callState) {
            TelephonyManager.CALL_STATE_RINGING -> "ringing"
            TelephonyManager.CALL_STATE_OFFHOOK -> "offhook"
            else -> "idle"
        }
    } catch (e: Exception) { "idle" }

    /** Ringing: answer. In a call: hang up. Otherwise: open the dialer. */
    @JavascriptInterface
    fun callAction() {
        val st = callState()
        a.runOnUiThread {
            try {
                val tm = a.getSystemService(TelecomManager::class.java)
                when {
                    st == "ringing" -> tm.acceptRingingCall()
                    st == "offhook" && Build.VERSION.SDK_INT >= 28 -> tm.endCall()
                    else -> a.startActivity(Intent(Intent.ACTION_DIAL))
                }
            } catch (e: Exception) {
                a.startActivity(Intent(Intent.ACTION_DIAL))
            }
        }
    }
}
